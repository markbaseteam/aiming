[[DeepWalk Online Learning of Social Representations]]

## 摘要

> We present DeepWalk, a novel approach for learning latent representations of vertices in a network. These latent  representations encode social relations in a continuous vector space, which is easily exploited by statistical models. DeepWalk generalizes recent advancements in language modeling and unsupervised feature learning (or deep learning) from sequences of words to graphs.

- 提出文章主要模型：[[DeepWalk]]
- 模型主要作用：学习网络中节点的隐藏表示
- 应用：社交关系在连续向量空间的表示

## 1. 简介

> DeepWalk takes a graph as input and produces a latent representation as an output. The result of applying our method to the well-studied Karate network is shown in Figure 1. The graph, as typically presented by force-directed  layouts, is shown in Figure 1a. Figure 1b shows the output of our method with 2 latent dimensions.
> ![[Pasted image 20230101224439.png]]

- DeepWalk的输入和输出
- [[../../数据集/Zachary's karate club]] 数据集