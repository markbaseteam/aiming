---
tags:
- 深度学习
- 深度学习/图深度学习
---

## 基本信息

- 主页：[[1403.6652] DeepWalk: Online Learning of Social Representations (arxiv.org)](https://arxiv.org/abs/1403.6652)
- 源文件：[1403.6652.pdf (arxiv.org)](https://arxiv.org/pdf/1403.6652.pdf)
- 作者：[[../../人物/Bryan Perozzi]]、[[../../人物/Rami AI-Rfou]]、[[../../人物/Steven Skiena]]
- 附件：[[1403.6652.pdf]]