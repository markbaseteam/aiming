---
tags:
- 神经网络
- 神经网络/图神经网络
- 深度学习
- 深度学习/图深度学习
---

- 中文名：图深度学习
- 英文名：Deep Learning on Graphs 
- 作者：[[../../人物/马耀]]、[[../../人物/汤继良]]
- 简介：图深度学习领域一本比较全面的书，适合入门和作为工具书。
-   书籍主页：[Deep Learning on Graphs (njit.edu)](https://web.njit.edu/~ym329/dlg_book/)
-   书籍获取：
    -   中文纸质书：[《图深度学习（全彩）(博文视点出品)》(马耀，汤继良)【摘要 书评 试读】- 京东图书 (jd.com)](https://item.jd.com/13221338.html?cu=true&utm_source=kong&utm_medium=tuiguang&utm_campaign=t_2009678457_&utm_term=fcda510799ae4c6497dfaca3bc8a0c08)
    -   英文纸质书&Kindle版：[Deep Learning on Graphs: Ma, Yao, Tang, Jiliang: 9781108831741: Amazon.com: Books](https://www.amazon.com/Deep-Learning-Graphs-Yao-Ma/dp/1108831745)
    -   免费英文电子书：[dlg_book.pdf (njit.edu)](https://web.njit.edu/~ym329/dlg_book/dlg_book.pdf)或[坚果云](https://www.jianguoyun.com/p/DSgVm7oQlszYChjmju0EIAA)
