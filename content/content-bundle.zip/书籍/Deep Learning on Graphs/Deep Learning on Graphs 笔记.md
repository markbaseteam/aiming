[[Deep Learning on Graphs]]
## 第4章 图嵌入

### 4.2 简单图的图嵌入

#### 4.2.1 保留节点共现

- 什么是节点共现？
- 随机游走（Ramdom Walk）
- [[DeepWalk]]
- node2vec
- LINE