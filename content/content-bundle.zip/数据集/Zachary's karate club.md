---
tags:
- 深度学习/图深度学习
- 社交网络
---

- 简介：[Zachary's karate club - Wikipedia](https://en.wikipedia.org/wiki/Zachary%27s_karate_club#:~:text=A%20social%20network%20of%20a%20karate%20club%20was,pairs%20of%20members%20who%20interacted%20outside%20the%20club.)